import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler, MessageHandler, Filters
from flask import Flask
from threading import Thread

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = "7961021844:AAEOLvUuNnUd_ldrMcWL_3MulqN04vgYb0w"
REQUIRED_CHANNELS = ["@lauch617", "@darkhasse", "@legitupdateer"]
ADMIN_USERNAME = "@Isaacadaku"
REFERRAL_REWARD = 20
MIN_WITHDRAWAL = 300

users_db = {}

def start(update: Update, context: CallbackContext):
    user = update.effective_user
    user_id = user.id
    args = context.args

    if user_id not in users_db:
        users_db[user_id] = {"balance": 0, "referrals": set(), "joined": False}
        if args:
            referrer_id = int(args[0])
            if referrer_id != user_id and referrer_id in users_db:
                if user_id not in users_db[referrer_id]["referrals"]:
                    users_db[referrer_id]["referrals"].add(user_id)
                    users_db[referrer_id]["balance"] += REFERRAL_REWARD

    keyboard = [[InlineKeyboardButton("✅ I’ve Joined", callback_data="check_membership")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    channels = "\n".join(f"👉 {c}" for c in REQUIRED_CHANNELS)

    update.message.reply_text(
        f"🎉 *Welcome to Naija Naira!*\n\nTo continue, join the channels below:\n\n{channels}",
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )

def check_membership(user_id, context: CallbackContext):
    for channel in REQUIRED_CHANNELS:
        try:
            member = context.bot.get_chat_member(channel, user_id)
            if member.status not in ['member', 'administrator', 'creator']:
                return False
        except:
            return False
    return True

def button_callback(update: Update, context: CallbackContext):
    query = update.callback_query
    user = query.from_user
    user_id = user.id
    query.answer()

    if check_membership(user_id, context):
        users_db[user_id]["joined"] = True
        ref_link = f"https://t.me/NaiijanairaBot?start={user_id}"
        query.edit_message_text(
            f"✅ You’ve joined all channels!\n\n"
            f"💸 Earn ₦{REFERRAL_REWARD} per referral.\n"
            f"🔗 *Your referral link:* {ref_link}\n\n"
            f"💼 /balance — check earnings\n💵 /withdraw — request payout",
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        query.edit_message_text("❌ You haven’t joined all required channels. Try again after joining.")

def balance(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    user_data = users_db.get(user_id)
    if not user_data or not user_data["joined"]:
        update.message.reply_text("Please use /start and join the channels first.")
        return
    bal = user_data["balance"]
    refs = len(user_data["referrals"])
    update.message.reply_text(f"💼 Balance: ₦{bal}\n👥 Referrals: {refs}")

def withdraw(update: Update, context: CallbackContext):
    user = update.effective_user
    user_id = user.id
    user_data = users_db.get(user_id)
    if not user_data or not user_data["joined"]:
        update.message.reply_text("Please use /start and join the channels first.")
        return
    bal = user_data["balance"]
    if bal < MIN_WITHDRAWAL:
        update.message.reply_text(f"❌ Minimum withdrawal is ₦{MIN_WITHDRAWAL}. Your balance is ₦{bal}.")
        return
    update.message.reply_text("💳 Send your *account number and bank name* to withdraw.", parse_mode=ParseMode.MARKDOWN)
    context.user_data["awaiting_withdrawal"] = True

def handle_messages(update: Update, context: CallbackContext):
    user = update.effective_user
    user_id = user.id
    user_data = users_db.get(user_id)
    if context.user_data.get("awaiting_withdrawal"):
        context.user_data["awaiting_withdrawal"] = False
        withdrawal_msg = (
            f"💸 *Withdrawal Request*\n\n"
            f"👤 {user.mention_markdown()}\n"
            f"🆔 ID: `{user_id}`\n"
            f"💰 Balance: ₦{user_data['balance']}\n"
            f"📨 Details: {update.message.text}"
        )
        context.bot.send_message(update.effective_chat.id, "✅ Withdrawal request sent to admin.")
        context.bot.send_message(ADMIN_USERNAME, withdrawal_msg, parse_mode=ParseMode.MARKDOWN)
        users_db[user_id]["balance"] = 0

def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_callback))
    dp.add_handler(CommandHandler("balance", balance))
    dp.add_handler(CommandHandler("withdraw", withdraw))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_messages))
    updater.start_polling()

    app = Flask('')
    @app.route('/')
    def home():
        return "Naija Naira Bot is alive."

    Thread(target=lambda: app.run(host="0.0.0.0", port=8080)).start()
    updater.idle()

if __name__ == "__main__":
    main()